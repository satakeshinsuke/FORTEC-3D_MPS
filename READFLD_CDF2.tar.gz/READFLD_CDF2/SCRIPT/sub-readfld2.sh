#!/bin/csh -f

set NMPI=4

setenv OMP_NUM_THREADS 4
setenv MKL_NUM_THREADS 4
setenv I_MPI_PLATFORM knl
setenv KMP_STACKSIZE 2G



set NAME=HIBP-IDO

set DATADIR=/home/satake/Work/HIBP-IDO/READFLD2
set OUTDIR=${DATADIR}

set JOBNAME1=${NAME}
set JOBNAME2=${JOBNAME1}

set READSTL=lhd

set EXECDIR=/home/satake/Documents/READFLD_CDF2
set EXECF=go_readfld2

# output files (readable text)
setenv FORT7 ${OUTDIR}/res-read.${JOBNAME2}
setenv FORT16 ${OUTDIR}/avs.${JOBNAME2}.dat
setenv FORT17 ${OUTDIR}/avs2.${JOBNAME2}.dat
setenv FORT8 ${OUTDIR}/spctl.${JOBNAME2}
setenv FORT9 ${OUTDIR}/volelm.${JOBNAME2}
# output for gsrake
setenv FORT12 ${OUTDIR}/gsrake-bmn.${JOBNAME2}
setenv FORT13 ${OUTDIR}/gsrake-prof.${JOBNAME2}
# input files
setenv FORT5 ${DATADIR}/input-read.${READSTL}

#setenv FORT20 ${DATADIR}/mode-select.${READSTL}

#for debug
setenv FORT80  ${OUTDIR}/debug80.${JOBNAME2}
setenv FORT81  ${OUTDIR}/debug81.${JOBNAME2}
setenv FORT90  ${OUTDIR}/debug90.${JOBNAME2}
setenv FORT91  ${OUTDIR}/debug91.${JOBNAME2}
setenv FORT92  ${OUTDIR}/debug92.${JOBNAME2}
setenv FORT93  ${OUTDIR}/debug93.${JOBNAME2}

#output for fortec3d
setenv FORT18 ${OUTDIR}/field-data.${JOBNAME2}
#output ps file
setenv FORT22 ${OUTDIR}/graph-${JOBNAME2}.ps
#output zahyo-henkan data for orbit plotting
setenv FORT23 ${OUTDIR}/xspctl.${JOBNAME2}
#center cell position information (nrcell,nacell,nzcell)
setenv FORT24 ${OUTDIR}/cell_rphiz.${JOBNAME2}
setenv FORT25 ${OUTDIR}/geom_scal.${JOBNAME2}.txt
setenv FORT26 ${OUTDIR}/geom_vect.${JOBNAME2}.txt
setenv FORT27 ${OUTDIR}/geom_data.${JOBNAME2}.bin
#

cd ${DATADIR}
# the boozmn_"fileext".nc file must exist in ${DATADIR}

(time mpirun -np ${NMPI} ${EXECDIR}/${EXECF}  ) 

#gzip -f ${FORT22}


