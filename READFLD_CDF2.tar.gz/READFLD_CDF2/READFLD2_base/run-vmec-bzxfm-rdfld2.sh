#!/bin/bash
#$ -cwd
#

NSMP=$1

DIRCODE=/home/satake/bin

# choose either _cdf or _txt version of execution files 
EXEC1=xvmec2000
EXEC2=xbooz_xform
#EXEC1=xvmec2000_txt
#EXEC2=xbooz_xform_txt

# number of parallel threads (working only for boozxform & readfld2)
export MKL_NUM_THREADS=$NSMP
export OMP_NUM_THREADS=$NSMP
export KMP_AFFINITY=none
export KMP_STACKSIZE=4G

ulimit -s unlimited

NAME=XXX

RESULT=/home/satake/Work/LHD-X_VMEC_KNOSOS/VMEC850/TEST_mimizuku_202103/${NAME}
INPUT_asc=$RESULT

#mkdir $RESULT

INPNAME=input.$NAME

cd $RESULT

#ln -sf $INPUT_asc/$INPNAME ./

# vmec
$DIRCODE/$EXEC1 $INPNAME &> $RESULT/msg-vmec.$NAME

#if [ -f wout_$NAME.nc ]; then
#    ncdump wout_$NAME.nc >| wout_$NAME.nc.txt
#fi

########
#
# note : in_booz.*** file must be in the $RESULT dir, or specified as a relative link
#        File extention for wout file (wout_***.nc or wout_***.txt) should be
#        given in the second line in_booz.*** file.
#        If the third line of in_booz.*** (give the radial mesh positions to be solved) = '888', 
#        then all except js=1 surfaces are solved in BOOZ_XFORM (Satake's modification)
INBOOZ=in_booz.$NAME

touch ${INBOOZ}

echo "80 40" >| ${INBOOZ}
echo "'${NAME}'" >> ${INBOOZ}
echo "888" >> ${INBOOZ}

#boozxform
$DIRCODE/$EXEC2  $INBOOZ &> msg-bzxfm.$NAME


#if(-f boozmn_{$NAME}.nc) then
#    ncdump boozmn_{$NAME}.nc >! boozmn_{$NAME}.nc.txt
#endif

if [ ! -d RZ_dump_$NAME ]; then
    mkdir RZ_dump_$NAME
fi

\mv -f RZ_*.txt sum_gmncb.txt RZ_dump_$NAME

tar -czf RZ_dump.tar.gz RZ_dump_$NAME
\rm -rf RZ_dump_$NAME


#########

NMPI=4
NSMP=$(( NSMP / NMPI ))

export OMP_NUM_THREADS=$NSMP
export MKL_NUM_THREADS=$NSMP

JOBNAME1=${NAME}
JOBNAME2=${JOBNAME1}

READSTL=lhd

EXECDIR=/home/satake/Documents/READFLD_CDF2
EXECF=go_readfld2

# output files (readable text)
export FORT7=res-read.${JOBNAME2}
export FORT16=avs.${JOBNAME2}.dat
export FORT17=avs2.${JOBNAME2}.dat
export FORT8=spctl.${JOBNAME2}
export FORT9=volelm.${JOBNAME2}
# output for gsrake
export FORT12=gsrake-bmn.${JOBNAME2}
export FORT13=gsrake-prof.${JOBNAME2}
# input files
export FORT5=input-read.${READSTL}

#export FORT20 ${DATADIR}/mode-select.${READSTL}

#for debug
export FORT80=debug80.${JOBNAME2}
export FORT81=debug81.${JOBNAME2}
export FORT90=debug90.${JOBNAME2}
export FORT91=debug91.${JOBNAME2}
export FORT92=debug92.${JOBNAME2}
export FORT93=debug93.${JOBNAME2}

#output for fortec3d
export FORT18=field-data.${JOBNAME2}
#output ps file
#export FORT22 graph-${JOBNAME2}.ps
#output zahyo-henkan data for orbit plotting
export FORT23=xspctl.${JOBNAME2}
#center cell position information (nrcell,nacell,nzcell)
export FORT24=cell_rphiz.${JOBNAME2}
export FORT25=geom_scal.${JOBNAME2}.txt
export FORT26=geom_vect.${JOBNAME2}.txt
export FORT27=geom_data.${JOBNAME2}.bin
#
ms
\cp -f ${EXECDIR}/${EXECF} ./

mpirun -np ${NMPI} -bind-to none ./${EXECF}

rm -f ./${EXECF}

i=`grep -c "readfield2 completed" $FORT7`
if [ $i ]; then
    echo "all done." >> log.txt
fi
