#!/bin/csh -f

setenv OMP_NUM_THREADS 5

set EXECNAME=go-avflvc-v4-das

set NAME=113208t4640

#### loop start
foreach DIRL( v4-2_phi1 )  


set DATDIR=/data/sht/satake/sample_minimum/${DIRL}

####
set ID=""

echo ${DATDIR}

set RESDIR=${DATDIR}/Graph

set BFLDDIR=${DATDIR}/../

set GSTBL=/dev/null
#set GSTBL=${BFLDDIR}/gm_table.${NAME}_it2
set FLDFILE=${BFLDDIR}/field-data.${NAME}


\cp -f /home/satake/FORTEC3D/F3D-MPS/AV-FLVC-phi/${EXECNAME} ${DATDIR}
cd  ${DATDIR}

if(! -d ${RESDIR}) then
mkdir ${RESDIR}
endif

#input file
setenv FORT15 ../input-av-flvc-v4-2.txt
setenv FORT8 input-f3d-v4-2_phi1_0.dat
setenv FORT28 ${FLDFILE}
#setenv FORT29 ${GSTBL}
setenv FORT98 out000.98

#output file
setenv FORT16 ${RESDIR}/msg-av

# list of mn-mode of NTV, NPV
setenv FORT21 ${RESDIR}/visc-mn.dat

#
#

#srun --mem-per-cpu=10000 ./${EXECNAME}
./${EXECNAME}

rm -f ./${EXECNAME}

##### loop end
end
#####


exit
