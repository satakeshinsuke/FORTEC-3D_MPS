#!/bin/csh -f

#PJM -L "rscunit=fx"
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM -L "elapse=0:15:00"
#PJM -j
#PJM -g 16222

setenv PARALLEL 16
setenv OMP_NUM_THREADS 16

set EXECNAME=go-findroot-v3

set NAME=130663t6040

set DATDIR=/data/lng/satake/IAEA2016/Dinklage/LHD${NAME}/
set RESDIR=${DATDIR}/fit_result

cp -f /home/satake/FORTEC3D/NTV/Plotting/AV-FLVC-v3_2/${EXECNAME} ${DATDIR}
cd  ${DATDIR}

if(! -d ${RESDIR}) then
mkdir ${RESDIR}
endif

#input file
setenv fu08 input_findroot.dat

#output debug message
setenv fu09 ${RESDIR}/msg-findroot.${NAME}

#output fittng result
setenv fu100 ${RESDIR}/er-fit-flux.${NAME}
setenv fu101 ${RESDIR}/amb-flux.${NAME}

#fortec-3d time average data paths (nspec * nfile)
setenv fu11 elc-1st+-0/Graph/ergm_fit.dat
setenv fu12 elc-1st+10/Graph/ergm_fit.dat
setenv fu13 elc-1st-15/Graph/ergm_fit.dat

setenv fu21 ion-1st+-0/Graph/ergm_fit.dat 
setenv fu22 ion-1st+10/Graph/ergm_fit.dat 
setenv fu23 ion-1st-15/Graph/ergm_fit.dat 

#
${DATDIR}/${EXECNAME}

rm -f ${DATDIR}/${EXECNAME}


exit 
