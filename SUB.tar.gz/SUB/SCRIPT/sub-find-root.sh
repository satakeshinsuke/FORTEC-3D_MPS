#!/bin/bash
#------- qsub option --------
#PBS -q gpu-b
#PBS --group=23298
#PBS -T intmpi
##PBS -T openmpi
#PBS -l elapstim_req=0:15:00
#PBS -b 1

#------- Program execution --------
export OMP_NUM_THREADS=8

EXECNAME=go-findroot-v5-das

NAME=CFQS_sample

DATDIR=/data/sht/satake/CFQS/FORTEC-3D/
RESDIR=${DATDIR}/fit_$NAME

cp -f /home/satake/FORTEC3D/F3D-MPS/OPEN-v4-2_MT_202308/AV-FLVC-v4-2_MT/${EXECNAME} ${DATDIR}
cd  ${DATDIR}


if [ ! -d "${RESDIR}" ]; then
    mkdir "${RESDIR}"
fi

#input file
export FORT8="input_findroot.dat"

#output debug message
export FORT9="${RESDIR}/msg-findroot.${NAME}"

#output fittng result
export FORT100="${RESDIR}/er-fit-flux.${NAME}"
export FORT101="${RESDIR}/amb-flux.${NAME}"
export FORT102="${RESDIR}/er-org-flux.${NAME}"

#fortec-3d time average data paths (nspec * nfile)
# note : for ion-only simulation with DKES/PENTA electoron, set zgam_ave.dat for electron table
#elc
export FORT11=CFQS_sample_er+01/Graph/zgam_ave.dat 
export FORT12=CFQS_sample_er+02/Graph/zgam_ave.dat 
export FORT13=CFQS_sample_er+03/Graph/zgam_ave.dat 
export FORT14=CFQS_sample_er-00/Graph/zgam_ave.dat 
export FORT15=CFQS_sample_er-01/Graph/zgam_ave.dat 
export FORT16=CFQS_sample_er-02/Graph/zgam_ave.dat 
export FORT17=CFQS_sample_er-03/Graph/zgam_ave.dat
#ion 1
export FORT21=CFQS_sample_er+01/Graph/ergm_fit_001.dat 
export FORT22=CFQS_sample_er+02/Graph/ergm_fit_001.dat 
export FORT23=CFQS_sample_er+03/Graph/ergm_fit_001.dat 
export FORT24=CFQS_sample_er-00/Graph/ergm_fit_001.dat 
export FORT25=CFQS_sample_er-01/Graph/ergm_fit_001.dat 
export FORT26=CFQS_sample_er-02/Graph/ergm_fit_001.dat 
export FORT27=CFQS_sample_er-03/Graph/ergm_fit_001.dat 

#
./${EXECNAME}

rm -f ${DATDIR}/${EXECNAME}


exit 
