#!/bin/bash
#------- qsub option --------
#PBS -q gpu-b
#PBS --group=23298
#PBS -T intmpi
##PBS -T openmpi
#PBS -l elapstim_req=0:10:00
#PBS -b 1

#------- Program execution --------

export OMP_NUM_THREADS=5

EXECNAME="go-avflvc-v4-das"

DIR="CFQS_sample_er+03"
#DIR="CFQS_sample_er-01 CFQS_sample_er-02 CFQS_sample_er-03"
#DIR="CFQS_sample_er-00 CFQS_sample_er+01 CFQS_sample_er+02"

for CASE in $DIR ; do

DATDIR="/data/sht/satake/CFQS/FORTEC-3D/${CASE}"

BFLDDIR="${DATDIR}/INPUT"

GSTBL="${BFLDDIR}/gm_table.CFQS_B01opt_Tix4"

FLDFILE="${BFLDDIR}/field-data.CFQS_B01opt_free"

# set the directry to write the results
RESDIR="${DATDIR}/Graph"

echo "${DATDIR}"

#####
\cp -f /home/satake/FORTEC3D/F3D-MPS/OPEN-v4-2_MT_202308/AV-FLVC-v4-2_MT/${EXECNAME} ${DATDIR}
cd  ${DATDIR}

if [ ! -d "${RESDIR}" ]; then
    mkdir "${RESDIR}"
fi

#input file
export FORT15="input-av-flvc-v4-2.txt"
export FORT8="input-f3d-v4-2_MT.dat"
export FORT28="${FLDFILE}"
export FORT29="${GSTBL}"
export FORT98="out000.98"

#output file
export FORT16="${RESDIR}/msg-av"
# list of mn-mode of NTV, NPV
export FORT21="${RESDIR}/visc-mn.dat"

#
#

./${EXECNAME} ${RESDIR}

rm -f ./${EXECNAME}

##### loop end
done
#####

exit
