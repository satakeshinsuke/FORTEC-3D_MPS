#!/bin/bash
#PBS --group 23298
###PBS -q small
###PBS -q small24VH
#PBS -q medium
#PBS -T necmpi
#PBS -l elapstim_req=0:45:00
#PBS -v NJOB=40
#PBS --venode=${NJOB}
#PBS -v OMP_NUM_THREADS=8
#PBS --venum-lhost=8

#PBS -v VE_PROGINF=detail
#PBS -v NMPI_PROGINF=detail
#PBS -v OMP_STACKSIZE=4G

#PBS -v EXECF=gontv-v4_2.go

#PBS -v VE_FORT91=./input-f3d-v4-2_MT.dat
#PBS -v VE_FORT19=./INPUT/gm_table.CFQS_B01opt_Tix4
###PBS -v VE_FORT20=./INPUT/
#PBS -v VE_FORT10=./INPUT/plasma_profiles_CFQS_Tix4.dat
#PBS -v VE_FORT18=./INPUT/field-data.CFQS_B01opt_free
#PBS -v VE_FORT97=./INPUT/seed-mt19937-1024-v03
#PBS -v VE_FORT150=./out000_phi1_output.145

#PBS -v VE_TRACEBACK=VERBOSE

cd $PBS_O_WORKDIR

cp -f /home/satake/FORTEC3D/F3D-MPS/v4-2_MT/${EXECF} ./

date
mpirun -np ${NJOB} ./${EXECF}
date

rm -f ${EXECF}

cp -f ${VE_FORT91} CONT_BKUP/

