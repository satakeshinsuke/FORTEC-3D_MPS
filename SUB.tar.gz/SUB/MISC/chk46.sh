#!/bin/csh -f

# This script is used for quick health-check of FORTEC-3D simulation (>ver.4-0)
# Requires "chk46.gpl" to plot figure

# 2020/03 for MPS version
#         

set SPCLIST="001 002 003"

foreach DIRL( 113208t4640_ti2.5_te3.6 )
###########################
cd ${DIRL}

if(! -d Graph ) then
mkdir Graph
endif

foreach SPC ( $SPCLIST )

    cat `ls -v out*_${SPC}.46` >! out46_${SPC}all

end

############################


gnuplot <<EOF


set style line  1 lw 3
set style line  2 lw 3 lc rgb '#33A02C'  # dark green
set style line  3 lw 3
set style line  4 lw 3
set style line  5 lw 3 lc rgb '#00F0FF' # thick cyan
set style line  6 lw 3 lc rgb '#AA9900' # dark yerrow
set style line  7 lw 3
set style line  8 lw 3
set style line  9 lw 3
set style line 10 lt 0 lw 3

set key out
set datafile fort
set term post col
set out "Graph/chk46_all.ps"

set xra [0:*]
set yra [*:*]
set xla "step"
set yla "counts"
set log y

# totcel=nrcell*nzcell*nacell*nobx*noby
#   ( see "out000.26" )

totcel=50*10*20*24*12

do for [SPC in "$SPCLIST"] {

OUT46="out46_".SPC."all"

set title "WAVE log (1) : species=".SPC

plot OUT46 u 1:2 tit "nomark" w l ls 1,\
     OUT46 u 1:3 tit "nminwv" w l ls 2,\
     OUT46 u 1:8 tit "passed" w l ls 3,\
     OUT46 u 1:9 tit "Pedge<0" w l ls 4,\
     OUT46 u 1:(totcel) tit "Total" w l ls 7

set title "WAVE log (2): species=".SPC

plot OUT46 u 1:4 tit "only-new" w l ls 1,\
     OUT46 u 1:5 tit "dsesv" w p ls 2 lw 1 ps 2,\
     OUT46 u 1:6 tit "cut-ww" w p ls 3 lw 1,\
     OUT46 u 1:7 tit "cut-wp" w p ls 4 lw 1,\
     OUT46 u 1:10 tit "dW_ave>>0" w l ls 5

}

EOF


###################

rm -f out46_*all

cd ../

end

