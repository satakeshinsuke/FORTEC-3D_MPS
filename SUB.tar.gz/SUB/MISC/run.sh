#!/bin/bash
#PBS --group 20214
#PBS -q medium
#PBS -T necmpi
#PBS -l elapstim_req=0:05:00
#PBS -v NJOB=72
#PBS --venode=${NJOB}
#PBS --venum-lhost=8
#PBS -v OMP_NUM_THREADS=8

#PBS -v VE_PROGINF=detail
#PBS -v NMPI_PROGINF=detail
#PBS -v OMP_STACKSIZE=1024M
#PBS -v VE_TRACEBACK=VERBOSE
#PBS -l coresz_prc=0

#PBS -v EXECF=gontv-v4_2.go
#PBS -v KMATH_RAND_JUMP_FILE_PATH=../jump
#PBS -w NAME=113208t4640
#PBS -w SFX=0
#PBS -v VE_FORT10=../plasma_profiles_lhd.dat
#PBS -v VE_FORT18=../field-data.${NAME}
#PBS -v VE_FORT19=../gm_table.dat
#PBS -v VE_FORT91=./input-f3d-v4-2_phi1_${SFX}.dat
#PBS -v VE_FORT20=../input-er.113208t4640_3ion_gme


cd $PBS_O_WORKDIR

cp -f /home/satake/FORTEC3D/F3D-MPS/v4-2_phi1/${EXECF} ./

date
mpirun -np ${NJOB} ./${EXECF}
date

rm -f ${EXECF}
